import React from "react";

export default function Favourites() {
  return (
    <div>
      <h2>Favourites</h2>
      <p>Favourite list will show here.</p>
    </div>
  );
}
