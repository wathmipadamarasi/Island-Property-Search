import React from "react";

export default function PropertyList() {
  return (
    <div>
      <h2>Property List</h2>
      <p>Properties will show here.</p>
    </div>
  );
}
