import { useState, useEffect, useMemo } from "react";

const STORAGE_KEY = "estate_agent_favourites";

function loadFromStorage() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    const parsed = data ? JSON.parse(data) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

export function useFavourites(allProperties = []) {
  const [favouriteIds, setFavouriteIds] = useState(() => loadFromStorage());

  // Save favourites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(favouriteIds));
    } catch (e) {
      // ignore storage errors
    }
  }, [favouriteIds]);

  // Get favourite property objects
  const favourites = useMemo(() => {
    return allProperties.filter((property) =>
      favouriteIds.includes(property.id)
    );
  }, [allProperties, favouriteIds]);

  // Add favourite (no duplicates)
  const addFavourite = (id) => {
    if (!id) return;
    setFavouriteIds((prev) =>
      prev.includes(id) ? prev : [...prev, id]
    );
  };

  // Remove favourite
  const removeFavourite = (id) => {
    setFavouriteIds((prev) => prev.filter((x) => x !== id));
  };

  // Clear all favourites
  const clearFavourites = () => {
    setFavouriteIds([]);
  };

  return {
    favouriteIds,
    favourites,
    addFavourite,
    removeFavourite,
    clearFavourites
  };
}
